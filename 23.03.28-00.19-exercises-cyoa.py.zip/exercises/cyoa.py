"""Choose your own adventure!"""

__author__ = "730404481"

points: int = 0
player: str = ""
SQUISH_MELLOW: str = "\U0001F9F8"
POPPER: str = "\U0001F389"
SMILE_EMOJI: str = "\U0001F600"
FRUIT_EMOJI: str = "\U0001F349"
VEGGIE_EMOJI: str = "\U0001F955"


def main() -> None:
    """Entering the experience."""
    global points
    greet()

    continue_playing: str = input(f" {player}, do you wish to play? Type 'Yes'if so!: ")
    while continue_playing == "Yes":
        points = 0
        age()
    
        fruits_or_veggies: str = input(f"Next question, {player}, Do you like fruits  {FRUIT_EMOJI} or veggies {VEGGIE_EMOJI} more? Enter 1 for fruits, and 2 for veggies.: ")
        if fruits_or_veggies == "1":
            points += 1
            print(f"Total Points: {points} ")
        else:
            veggies(0)
        
        print(f"Final step {player} {SMILE_EMOJI}! You will now be given a random integer from 1-10 that will help determine which Squishmellow you are!")
        random()
        
        print(f"Okay {player}! I have determined what squishmellow you are! You have {points} total points. Here are your results:")
        if points <= 4:
            Aria()     

        if points > 4 and points <= 7:
            Cassie()

        if points > 7:
            Antonio()
        
        continue_playing = input("Do you want to play again?: ")
        if continue_playing == "No":
            print("Ok:(. Goodbye!")
    

def greet() -> None:
    """Welcoming player and asking for their name."""
    print(f"Welcome {SMILE_EMOJI} ! In this game, based off an array of questions, we will determine which Squishmellow you are!")
    global player 
    player = input("What is your name?")


def age() -> None:
    """Ask what age the player is."""
    asking_age: int = int(input(f"First question {player}. How old are you? {POPPER}:  "))
    global points
    if asking_age < 17:
        points += 1
        print(f"Total Points: {points} ")
    else:
        points += 3
        print(f"Total Points: {points} ")

    return 
    

def veggies(points_gained_from_fruits_or_veggies: int) -> int:
    """If player user prefers veggies over fruits."""
    global points
    global player
    points += 4
    print(f"Total Points: {points} ")
    return points


def random() -> int:
    """Gives the player a random integer from  1-10."""
    global points
    import random
    random_number: int = random.randint(1, 10)
    print(f" You got {random_number}!")

    if random_number % 2 == 0:
        points += 1
    else:
        points += 2

    return random_number

        
def Aria() -> None:
    """The amount of points recieved is equal or less than 4. You got Aria!"""
    print(F" You got Aria {SQUISH_MELLOW}! She is your next party guru. When she's not planning her next event, you can find her and her Uni-gals exploring. How does she unwind? By being silly with her family and friends.")


def Cassie() -> None:
    """The amount of points recieved is greater than 4 but less than or equal to 7. You got Cassie!"""
    print(f"You got Cassie {SQUISH_MELLOW}! She is the head nurse at the hospital where she works to help save lives every day. Cassie knows hospitals can be scary so she keeps lollipops and stickers in her pocket for any mini-mallow patients she sees. Don’t be shy, give Cassie a smile or a wave if you see her rushing around!")


def Antonio() -> None:
    """The amount of points recieved is greater than 7. You got Antonio!"""
    print(f"You got Antonio {SQUISH_MELLOW}! He is super smart and loves a good challenge. You can find him working on crosswords, putting together puzzles, and solving riddles! Got something you can't figure out? Ask Antoine! He is always willing to lend a helping hand.")


if __name__ == "__main__":
    main()